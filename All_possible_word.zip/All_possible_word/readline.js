var fs = require("fs");
const readline = require('readline').createInterface({
    input: process.stdin,
    output: process.stdout
  })
  
  readline.question(`Enter your input string=>:`, name => {
      let str=name;
      
      //let str = "blade";
      // let array = [];
      // Intitializing the readFileLines with the file
      const readFileLines = (filename) =>
        fs.readFileSync(filename).toString("UTF8").split("\r\n");
      
      // Calling the readFiles function with file name
      let array = readFileLines("dict.txt");
      //console.log(array.length);
      //console.log(array);
       //console.log(arr.length);
      let count = array.length;
      //const arr=['alb',abl]
      let BS = function (arr, x, start, end) {
        // Base Condition
        if (start > end) return false;
        // Find the middle index
        let mid = Math.floor((start + end) / 2);
        // Compare mid with given key x
        if (arr[mid] === x) return true;
        // If element at mid is greater than x,
        // search in the left half of mid
        if (arr[mid] > x) return BS(arr, x, start, mid - 1);
        // If element at mid is smaller than x,
        // search in the right half of mid
        else return BS(arr, x, mid + 1, end);
      };
      // let a1 = [];
      let permutation = (str, result) => {
        if (str.length == 0) {
          //  console.log(result);
        }
        for (let i = 0; i < str.length; i++) {
          let rest = str.substring(0, i) + str.substring(i + 1);
          let st = result + str[i];
         let st2= st.toLowerCase();
          if (st2.length > 2) {
            if (BS(array, st2, 0, count)==true){
              console.log(st.toUpperCase());
            }
          
          }
          permutation(rest, st);
        }
      };
      
      permutation(str, "");
      // console.log(a1);
      
    readline.close()
  })