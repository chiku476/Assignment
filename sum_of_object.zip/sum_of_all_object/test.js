// Solution for question no. 3
     
const Input =  [{x: 1}, {x: 2}, {x: 3}, {x: [{x: 4}, {x: 5}, {x: 6}, {x: [{x: 7}, {x: [{x: 8}]}]}]}, {x: 9}];
// map() method is used to iterate over an array and calling function on every element of array
 let array= Input.map((idy)=>{return idy.x});
  let sum=0;
  for(let x=0; x<array.length;x++){ // Looping over array
   if(typeof(array[x])=="object"){ // If type of array element is object 
       let Destructure= array[x].map((id)=>{return id.x});
       array=[...array,...Destructure]; //concatenating tow array using spread operator 
   }
   else{
       sum=sum+array[x];//sum of array object
   }
    
 }
console.log(sum);